library(shiny)
ui<-fluidRow(verticalLayout("This is example of Split Layout",
                            "Random two Plots",
                            splitLayout(plotOutput("plot1"),plotOutput("plot2"))))
server<-function(input,output) {
  
  output$plot1 <- renderPlot(plot(cars))
  output$plot2 <- renderPlot(plot(pressure))
}
shinyApp(ui = ui, server = server)
