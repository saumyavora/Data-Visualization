library(shiny)
ui<-fluidPage(
  fluidRow(
  titlePanel("Basic widgets"),
  fluidRow(
    column(4,
           h3("Buttons"),
           actionButton("action", "Action1"),
           br(),
           br(), 
           verbatimTextOutput("v1")),
    column(4,
           h3("Single checkbox"),
           checkboxInput("checkbox", "Choice A", value = TRUE),
           verbatimTextOutput("v2")),
    column(4,
           checkboxGroupInput("checkboxgroup",
                              h3("Checkbox group"),
                              choices=list("Choice 1"=1,
                                           "Choice 2"=2,
                                           "Choice 3"=3),
                              selected=1),
           verbatimTextOutput("v3"))),
  
  fluidRow(
    column(4, 
           dateInput("date", 
                     h3("Date input"), 
                     value = "2019-11-02"),
           verbatimTextOutput("v4")),
    
    column(4,
           dateRangeInput("dates", h3("Date range")),
           fluidRow(column(10,verbatimTextOutput("v5")))),
    
    column(4,
           fileInput("file", h3("File input"))),
  ),
  fluidRow(
    column(4, 
           numericInput("nume", 
                        h3("Numeric input"), 
                        value = 1),
           verbatimTextOutput("v6")
    ),
    
    column(4,
           radioButtons("radio", h3("Radio buttons"),
                        choices = list("Choice 1" = 1, "Choice 2" = 2,
                                       "Choice 3" = 3),selected = 1),
           verbatimTextOutput("v7")),
    
    column(4,
           selectInput("select", h3("Select box"), 
                       choices = list("Choice 1" = 1, "Choice 2" = 2,
                                      "Choice 3" = 3), selected = 1),
           verbatimTextOutput("v8")),
  ),
  
  fluidRow(
    column(4, 
           sliderInput("slider1", h3("Slider1"),
                       min = 0, max = 100, value = 50),
           verbatimTextOutput("v9")),
    
    column(4, 
           textInput("text", h3("Text input"), 
                     value = "Enter text..."),
           verbatimTextOutput("v10")),
    
    column(4,
           sliderInput("slider2", h3("Slider2"),
                       min = 0, max = 100, value = c(25, 75)),
           verbatimTextOutput("v11"))
  )))




server<-function(input,output) {


output$v1=renderPrint({input$action})
output$v2=renderPrint({input$checkbox})
output$v3=renderPrint({input$checkboxgroup})
output$v4=renderPrint({input$date})
output$v5=renderPrint({input$dates})
output$v6=renderPrint({input$nume})
output$v7=renderPrint({input$radio})
output$v8=renderPrint({input$select})
output$v9=renderPrint({input$slider1})
output$v10=renderPrint({input$text})
output$v11=renderPrint({input$slider2})
}

shinyApp(ui = ui, server = server)

