library(shiny)
ui<-verticalLayout("Saumya", 
               "This is example of Vertical Layout",
               "Random two Plots",plotOutput("plot1"),plotOutput("plot2"))
server<-function(input,output) {
  output$plot1 <- renderPlot(plot(cars))
  output$plot2 <- renderPlot(plot(pressure))
  
}
shinyApp(ui = ui, server = server)
