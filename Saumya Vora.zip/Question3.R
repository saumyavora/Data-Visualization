library(shiny)
ui<-fluidPage(
  titlePanel(title="Question 3"),
  fluidRow(
    column(4,   sliderInput("num",
                            "Choose a number",
                            min = 2,
                            max = 1000,
                            value = 30)),
    column(4,   radioButtons("dist", "Distribution type:",
                             c("Normal" = "norm",
                               "Uniform" = "unif"
                             ))),
    
    column(4, actionButton(inputId = "btn",label="Update"))
  ),
  mainPanel(column(11, 
                   plotOutput("distPlot"),
                   
                   verbatimTextOutput("text")
  )))
server<-
  function(input,output) {
    vals = eventReactive(input$btn, {
      runif(input$num)
    })
    output$distPlot <- renderPlot({
      dist = switch(input$dist,
                    norm = rnorm,
                    unif = runif,
                    rnorm)
      hist(dist(vals()), main="Distribution")
    })
    output$text = renderPrint({
      
      summary(dist(vals()))
    })
  }

shinyApp(ui = ui, server = server)
