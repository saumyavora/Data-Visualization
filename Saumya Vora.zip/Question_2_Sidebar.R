library(shiny)
ui<-fluidPage(
  fluidRow(
    verticalLayout( 
                   "This is example of Sidebar Layout"),
                   
    sidebarLayout(position = "right",
              sidebarPanel("Sidebar",
                           textInput("txt1", "Type your name", "Name "),
                           selectInput("side", "what is your graduation year:", choices = c("2019", "2020")),
                           verbatimTextOutput("txtout"),
                           verbatimTextOutput("out"),
                          ),
mainPanel(
  ))))
server<-
  function(input,output) {
    output$txtout <- renderText({paste(input$txt1)})
    output$out <- renderText({paste(input$side)})
  }
shinyApp(ui = ui, server = server)
